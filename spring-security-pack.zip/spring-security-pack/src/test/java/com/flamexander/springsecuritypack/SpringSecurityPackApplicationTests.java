package com.flamexander.springsecuritypack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityPackApplicationTests {

	@Test
	void contextLoads() {
	}

}
